-- 1) Séries europeias, com >3 temporadas e premiação de atores em ≥2 temporadas
SELECT s.titulo
FROM   serie s
JOIN   pais p    ON s.id_pais = p.id_pais
JOIN   temporada t ON s.id_serie = t.id_serie
LEFT   JOIN premiacao pr
       ON pr.id_serie = s.id_serie
      AND pr.id_ator IS NOT NULL
GROUP  BY s.id_serie, s.titulo, p.continente
HAVING p.continente = 'Europa'
   AND COUNT(DISTINCT t.id_temporada)       > 3
   AND COUNT(DISTINCT pr.id_temporada)      >= 2
;
 
-- 2) Filmes premiados nas categorias diretor e ator
SELECT f.titulo
FROM   filme f
JOIN   premiacao pr ON pr.id_filme = f.id_filme
GROUP  BY f.id_filme, f.titulo
HAVING COUNT(DISTINCT CASE WHEN pr.id_ator    IS NOT NULL THEN pr.id_premiacao END) > 0
   AND COUNT(DISTINCT CASE WHEN pr.id_diretor IS NOT NULL THEN pr.id_premiacao END) > 0
;
 
-- 3) Séries não-europeias, com mais atrizes que atores e episódios com >1 diretor
SELECT s.titulo
FROM   serie s
JOIN   pais p    ON s.id_pais = p.id_pais
WHERE  p.continente <> 'Europa'
  AND  (
         SELECT COUNT(DISTINCT a.id_ator)
         FROM   temporada t2
         JOIN   episodio e2      ON t2.id_temporada = e2.id_temporada
         JOIN   ator_episodio ae ON ae.id_episodio  = e2.id_episodio
         JOIN   ator a           ON a.id_ator        = ae.id_ator
         WHERE  t2.id_serie = s.id_serie
           AND  a.sexo      = 'F'
       )
     >
       (
         SELECT COUNT(DISTINCT a.id_ator)
         FROM   temporada t2
         JOIN   episodio e2      ON t2.id_temporada = e2.id_temporada
         JOIN   ator_episodio ae ON ae.id_episodio  = e2.id_episodio
         JOIN   ator a           ON a.id_ator        = ae.id_ator
         WHERE  t2.id_serie = s.id_serie
           AND  a.sexo      = 'M'
       )
  AND  EXISTS (
         SELECT 1
         FROM   temporada t3
         JOIN   episodio e3        ON t3.id_temporada     = e3.id_temporada
         JOIN   diretor_episodio de ON de.id_episodio     = e3.id_episodio
         WHERE  t3.id_serie = s.id_serie
         GROUP  BY e3.id_episodio
         HAVING COUNT(de.id_diretor) > 1
       )
;
 
-- 4) Premiações de filmes <2003, gênero Aventura e classificação >12 anos
SELECT pr.titulo_premio,
       pr.ano_premio,
       f.titulo       AS filme
FROM   premiacao pr
JOIN   filme f      ON pr.id_filme       = f.id_filme
JOIN   genero g     ON f.id_genero       = g.id_genero
JOIN   classificacao_etaria ce
                 ON f.id_classificacao = ce.id_classificacao
WHERE  f.ano_lanc    < 2003
  AND  g.descricao   = 'Aventura'
  AND  ce.idade_minima > 12
;
 
-- 5) Personagens de atores que fizeram filmes de Romance e nunca foram premiados
SELECT DISTINCT p.nome_personagem
FROM   personagem p
JOIN   ator_filme af ON p.id_personagem = af.id_personagem
JOIN   ator a        ON af.id_ator      = a.id_ator
JOIN   filme f       ON af.id_filme     = f.id_filme
JOIN   genero g      ON f.id_genero     = g.id_genero
WHERE  g.descricao    = 'Romance'
  AND  NOT EXISTS (
         SELECT 1
         FROM   premiacao pr
         WHERE  pr.id_ator = a.id_ator
       )
;
 
-- 6) Títulos de episódios (alfab.) de séries com >3 temporadas, classificação 'L' e dirigidos por mulheres
SELECT DISTINCT e.titulo
FROM   serie s
JOIN   classificacao_etaria ce ON s.id_classificacao = ce.id_classificacao
JOIN   temporada t ON s.id_serie      = t.id_serie
JOIN   episodio e  ON t.id_temporada  = e.id_temporada
JOIN   diretor_episodio de ON e.id_episodio = de.id_episodio
JOIN   diretor d   ON de.id_diretor     = d.id_diretor
WHERE  ce.etiqueta = 'L'
  AND (
         SELECT COUNT(*)
         FROM   temporada t2
         WHERE  t2.id_serie = s.id_serie
       ) > 3
  AND  d.sexo = 'F'
ORDER  BY e.titulo
;
 
-- 7) Filmes após 2003 com atores que participaram de séries premiadas
SELECT DISTINCT f.titulo
FROM   filme f
JOIN   ator_filme af ON f.id_filme = af.id_filme
JOIN   ator a        ON af.id_ator = a.id_ator
WHERE  f.ano_lanc > 2003
  AND  EXISTS (
         SELECT 1
         FROM   premiacao pr
         JOIN   temporada t ON pr.id_serie = t.id_serie OR pr.id_temporada = t.id_temporada
         JOIN   episodio e ON t.id_temporada = e.id_temporada
         JOIN   ator_episodio ae ON ae.id_episodio = e.id_episodio
         WHERE  ae.id_ator = a.id_ator
       )
;
 
-- 8) Atores que participaram só de séries antes de 2003 e só de filmes após 2003 (mais recente → mais antigo)
SELECT a.nome
FROM   ator a
WHERE  EXISTS (
         SELECT 1
         FROM   ator_episodio ae
         JOIN   episodio e ON ae.id_episodio = e.id_episodio
         JOIN   temporada t ON e.id_temporada = t.id_temporada
         JOIN   serie s ON t.id_serie = s.id_serie
         WHERE  ae.id_ator = a.id_ator
           AND  s.ano_estreia < 2003
       )
  AND  NOT EXISTS (
         SELECT 1
         FROM   ator_episodio ae
         JOIN   episodio e ON ae.id_episodio = e.id_episodio
         JOIN   temporada t ON e.id_temporada = t.id_temporada
         JOIN   serie s ON t.id_serie = s.id_serie
         WHERE  ae.id_ator = a.id_ator
           AND  s.ano_estreia >= 2003
       )
  AND  EXISTS (
         SELECT 1
         FROM   ator_filme af
         JOIN   filme f ON af.id_filme = f.id_filme
         WHERE  af.id_ator = a.id_ator
           AND  f.ano_lanc > 2003
       )
  AND  NOT EXISTS (
         SELECT 1
         FROM   ator_filme af
         JOIN   filme f ON af.id_filme = f.id_filme
         WHERE  af.id_ator = a.id_ator
           AND  f.ano_lanc <= 2003
       )
ORDER  BY (
         SELECT MAX(f2.ano_lanc)
         FROM   filme f2
         JOIN   ator_filme af2 ON f2.id_filme = af2.id_filme
         WHERE  af2.id_ator = a.id_ator
       ) DESC
;
 
-- 9) Episódios de séries com ≥4 eps/temporada (dur >45), e com <3 atores nesses eps
WITH eps_por_temp AS (
  SELECT t.id_serie, t.id_temporada, COUNT(*) AS qtd
  FROM   temporada t
  JOIN   episodio e ON t.id_temporada = e.id_temporada
  WHERE  e.duracao_min > 45
  GROUP  BY t.id_serie, t.id_temporada
), series_valid AS (
  SELECT id_serie
  FROM   eps_por_temp
  GROUP  BY id_serie
  HAVING MIN(qtd) >= 4
)
SELECT e.id_episodio, e.titulo, e.duracao_min,
       (SELECT COUNT(*) FROM ator_episodio ae WHERE ae.id_episodio = e.id_episodio) AS qtd_atores
FROM   episodio e
JOIN   temporada t ON e.id_temporada = t.id_temporada
WHERE  t.id_serie IN (SELECT id_serie FROM series_valid)
  AND  e.duracao_min > 45
  AND  (SELECT COUNT(*) FROM ator_episodio ae WHERE ae.id_episodio = e.id_episodio) < 3
;
 
-- 10) Filmes em 4K dirigidos por um de seus atores
SELECT f.titulo
FROM   filme f
JOIN   diretor_filme df ON f.id_filme = df.id_filme
WHERE  f.resolucao = '4K'
  AND  df.id_diretor IN (
         SELECT af.id_ator
         FROM   ator_filme af
         WHERE  af.id_filme = f.id_filme
       )
;
 
-- 11) Filmes >3h, ator interpretando a si mesmo, <2010 e com alguma premiação
SELECT DISTINCT f.titulo
FROM   filme f
JOIN   ator_filme af ON f.id_filme = af.id_filme
JOIN   personagem p ON af.id_personagem = p.id_personagem
JOIN   ator a       ON af.id_ator = a.id_ator
WHERE  f.duracao_min > 180
  AND  p.nome_personagem = a.nome
  AND  f.ano_lanc < 2010
  AND  EXISTS (
         SELECT 1 FROM premiacao pr
         WHERE  pr.id_filme = f.id_filme
            OR  pr.id_ator  IN (SELECT id_ator FROM ator_filme WHERE id_filme = f.id_filme)
            OR  pr.id_diretor IN (SELECT id_diretor FROM diretor_filme WHERE id_filme = f.id_filme)
       )
;
 
-- 12) Episódios, atores e avaliações de temporadas com avg(av) >7.5, avg(dur) entre 45–50, gênero Comédia/Ação e >1 diretor na temp.
SELECT e.id_episodio,
       e.titulo     AS episodio,
       a.nome       AS ator,
       av.nota      AS avaliacao
FROM   serie s
JOIN   genero g ON s.id_genero = g.id_genero
JOIN   temporada t ON s.id_serie = t.id_serie
JOIN   episodio e ON t.id_temporada = e.id_temporada
JOIN   avaliacao av ON av.id_episodio = e.id_episodio
JOIN   ator a ON av.id_ator = a.id_ator
WHERE  g.descricao IN ('Comédia','Ação')
  AND  (
         SELECT AVG(nota)
         FROM   avaliacao av2
         WHERE  av2.id_episodio IN (
                  SELECT id_episodio FROM episodio WHERE id_temporada = t.id_temporada
                )
       ) > 7.5
  AND  (
         SELECT AVG(duracao_min)
         FROM   episodio e2
         WHERE  e2.id_temporada = t.id_temporada
       ) BETWEEN 45 AND 50
  AND  (
         SELECT COUNT(DISTINCT de.id_diretor)
         FROM   diretor_episodio de
         JOIN   episodio e3 ON de.id_episodio = e3.id_episodio
         WHERE  e3.id_temporada = t.id_temporada
       ) > 1
ORDER  BY s.titulo, t.numero_temp, e.numero_ep
;
 
-- 13) Avaliações médias de séries e filmes por diretor, agrupado por tipo
SELECT d.nome       AS diretor,
       'Filme'      AS tipo,
       AVG(av.nota) AS media_avaliacao
FROM   diretor d
JOIN   diretor_filme df ON d.id_diretor = df.id_diretor
JOIN   avaliacao av     ON av.id_filme  = df.id_filme
GROUP  BY d.nome
UNION ALL
SELECT d.nome       AS diretor,
       'Série'      AS tipo,
       AVG(av.nota) AS media_avaliacao
FROM   diretor d
JOIN   diretor_episodio de ON d.id_diretor = de.id_diretor
JOIN   avaliacao av        ON av.id_episodio = de.id_episodio
GROUP  BY d.nome
;
 
-- 14) Filmes e séries de Comédia com ≥2 atores avaliando >8.5
SELECT f.titulo, 'Filme' AS tipo
FROM   filme f
JOIN   genero g ON f.id_genero = g.id_genero
JOIN   avaliacao av ON av.id_filme = f.id_filme
WHERE  g.descricao = 'Comédia'
GROUP  BY f.id_filme, f.titulo
HAVING SUM(CASE WHEN av.nota > 8.5 THEN 1 ELSE 0 END) >= 2
UNION ALL
SELECT s.titulo, 'Série' AS tipo
FROM   serie s
JOIN   genero g ON s.id_genero = g.id_genero
JOIN   temporada t ON s.id_serie = t.id_serie
JOIN   episodio e ON t.id_temporada = e.id_temporada
JOIN   avaliacao av ON av.id_episodio = e.id_episodio
WHERE  g.descricao = 'Comédia'
GROUP  BY s.id_serie, s.titulo
HAVING SUM(CASE WHEN av.nota > 8.5 THEN 1 ELSE 0 END) >= 2
;
 
-- 15) Triggers para remover premiações ao excluir filme ou série
CREATE OR REPLACE TRIGGER trg_remove_premios_filme
AFTER DELETE ON filme
FOR EACH ROW
BEGIN
  DELETE FROM premiacao WHERE id_filme = :old.id_filme;
END;
/
 
CREATE OR REPLACE TRIGGER trg_remove_premios_serie
AFTER DELETE ON serie
FOR EACH ROW
BEGIN
  DELETE FROM premiacao WHERE id_serie = :old.id_serie;
END;
/
 
-- 16) Function que retorna total de premiações de cada filme
CREATE OR REPLACE FUNCTION fn_total_premios_por_filme
RETURN SYS_REFCURSOR
IS
  rc SYS_REFCURSOR;
BEGIN
  OPEN rc FOR
    SELECT f.id_filme,
           f.titulo,
           COUNT(pr.id_premiacao) AS total_premios
    FROM   filme f
    LEFT   JOIN premiacao pr
           ON pr.id_filme = f.id_filme
              OR pr.id_ator IN (SELECT id_ator FROM ator_filme WHERE id_filme = f.id_filme)
              OR pr.id_diretor IN (SELECT id_diretor FROM diretor_filme WHERE id_filme = f.id_filme)
    GROUP  BY f.id_filme, f.titulo;
  RETURN rc;
END;
/
 
-- 17) Procedure para inativar exibição de filmes e séries de um país
CREATE OR REPLACE PROCEDURE pr_inativar_obras_por_pais (p_id_pais NUMBER)
IS
BEGIN
  UPDATE filme SET ativo = 'N' WHERE id_pais = p_id_pais;
  UPDATE serie SET ativa = 'N' WHERE id_pais = p_id_pais;
END;
/