-- Script SQL Completo para Inserção de Dados
-- Deve ser executado em um banco de dados VAZIO com o esquema de tabelas já criado.

-- Inserções para a tabela PAIS
INSERT INTO pais (nome, continente) VALUES ('Estados Unidos', 'América do Norte'); 
INSERT INTO pais (nome, continente) VALUES ('Japão', 'Ásia');                     
INSERT INTO pais (nome, continente) VALUES ('Canadá', 'América do Norte');        
INSERT INTO pais (nome, continente) VALUES ('Brasil', 'América do Sul');          
INSERT INTO pais (nome, continente) VALUES ('França', 'Europa');                  
INSERT INTO pais (nome, continente) VALUES ('Alemanha', 'Europa');                
INSERT INTO pais (nome, continente) VALUES ('Espanha', 'Europa');                 
INSERT INTO pais (nome, continente) VALUES ('Itália', 'Europa');                  
INSERT INTO pais (nome, continente) VALUES ('Austrália', 'Oceania');              

-- Inserções para a tabela GENERO
INSERT INTO genero (descricao) VALUES ('Drama');    
INSERT INTO genero (descricao) VALUES ('Comédia');  
INSERT INTO genero (descricao) VALUES ('Ação');     
INSERT INTO genero (descricao) VALUES ('Suspense'); 
INSERT INTO genero (descricao) VALUES ('Aventura'); 
INSERT INTO genero (descricao) VALUES ('Romance');  

-- Inserções para a tabela CLASSIFICACAO_ETARIA
INSERT INTO classificacao_etaria (etiqueta, idade_minima) VALUES ('L', 0);   
INSERT INTO classificacao_etaria (etiqueta, idade_minima) VALUES ('12', 12); 
INSERT INTO classificacao_etaria (etiqueta, idade_minima) VALUES ('16+', 16);
INSERT INTO classificacao_etaria (etiqueta, idade_minima) VALUES ('18+', 18);

-- Inserções para a tabela ATOR
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Atriz A', 'F', TO_DATE('1985-05-15', 'YYYY-MM-DD'), 1); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Atriz B', 'F', TO_DATE('1990-03-20', 'YYYY-MM-DD'), 1); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Atriz C', 'F', TO_DATE('1978-11-01', 'YYYY-MM-DD'), 2);
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Atriz D', 'F', TO_DATE('1995-07-22', 'YYYY-MM-DD'), 3); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator X', 'M', TO_DATE('1980-01-10', 'YYYY-MM-DD'), 1);  
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Y', 'M', TO_DATE('1988-09-05', 'YYYY-MM-DD'), 2);  
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Z', 'M', TO_DATE('1975-04-12', 'YYYY-MM-DD'), 3);  
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Anna Keller', 'F', TO_DATE('1982-02-28', 'YYYY-MM-DD'), 6); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Carlos Ramirez', 'M', TO_DATE('1979-06-14', 'YYYY-MM-DD'), 7); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Marco Bellini', 'M', TO_DATE('1970-10-03', 'YYYY-MM-DD'), 8); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Sophie Dubois', 'F', TO_DATE('1989-01-19', 'YYYY-MM-DD'), 5); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Lucas Silva', 'M', TO_DATE('1993-08-17', 'YYYY-MM-DD'), 4); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Yuki Tanaka', 'F', TO_DATE('1991-03-25', 'YYYY-MM-DD'), 2);
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Aiko Nakamura', 'F', TO_DATE('1987-12-09', 'YYYY-MM-DD'), 2); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Mika Sato', 'F', TO_DATE('1994-06-11', 'YYYY-MM-DD'), 2); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Kenji Yamamoto', 'M', TO_DATE('1983-07-07', 'YYYY-MM-DD'), 2); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Velho A', 'M', TO_DATE('1950-01-01', 'YYYY-MM-DD'), 1); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Velho B', 'M', TO_DATE('1955-02-02', 'YYYY-MM-DD'), 1);
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Atriz Nova X', 'F', TO_DATE('2000-03-03', 'YYYY-MM-DD'), 1); 
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Atriz Nova Y', 'F', TO_DATE('2002-04-04', 'YYYY-MM-DD'), 1); 

-- Inserções para a tabela DIRETOR
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Diretor 1', 'M', TO_DATE('1970-01-01', 'YYYY-MM-DD'), 1); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Diretor 2', 'M', TO_DATE('1965-02-02', 'YYYY-MM-DD'), 1); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Diretor 3', 'M', TO_DATE('1972-03-03', 'YYYY-MM-DD'), 2); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Diretor 4', 'M', TO_DATE('1980-04-04', 'YYYY-MM-DD'), 3); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Francesca Rossi', 'F', TO_DATE('1978-05-05', 'YYYY-MM-DD'), 8); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Jean Pierre', 'M', TO_DATE('1960-06-06', 'YYYY-MM-DD'), 5); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Hans Müller', 'M', TO_DATE('1973-07-07', 'YYYY-MM-DD'), 6); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Takeshi Morita', 'M', TO_DATE('1968-08-08', 'YYYY-MM-DD'), 2); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Naomi Fujiwara', 'F', TO_DATE('1971-09-09', 'YYYY-MM-DD'), 2); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Diretora Antiga A', 'F', TO_DATE('1960-01-01', 'YYYY-MM-DD'), 1); 
INSERT INTO diretor (nome, sexo, data_nasc, id_pais) VALUES ('Diretora Antiga B', 'F', TO_DATE('1962-02-02', 'YYYY-MM-DD'), 1); 

-- Inserções para a tabela PERSONAGEM
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Generico 1');  
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Generico 2');  
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Generico 3');  
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Generico 4');  
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Generico 5');  
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Generico 6');  
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Generico 7');  
INSERT INTO personagem (nome_personagem) VALUES ('Ator Velho A');           
INSERT INTO personagem (nome_personagem) VALUES ('Ator Velho B');          
INSERT INTO personagem (nome_personagem) VALUES ('Ator X');                


-- Inserções para a tabela FILME
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Vento Sombrio', 2020, 120, '1080p', 1, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Segredos da Cidade', 2021, 110, 'HD', 4, 2, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('A Fuga', 2019, 95, '4K', 3, 3, 4, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('O Resgate', 2023, 150, '1080p', 3, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('A Intriga', 2022, 130, '4K', 4, 2, 4, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('O Último Suspiro', 2021, 140, '1080p', 1, 3, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Expedição Perdida', 2000, 160, 'SD', 5, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Tesouro Antigo', 2002, 145, 'SD', 5, 2, 4, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('O Portal Misterioso', 2001, 155, 'SD', 5, 3, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Amor em Nova York', 2010, 100, '1080p', 6, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Destinos Cruzados', 2011, 110, '720p', 6, 3, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Segredos de Verão', 2012, 95, '1080p', 6, 4, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Renascimento', 2005, 120, 'SD', 1, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Conexão Futura', 2008, 130, 'SD', 3, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Visões do Amanhã', 2010, 140, '1080p', 4, 2, 4, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Filme Novo do Ator A', 2015, 120, '1080p', 1, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Filme Novo do Ator B', 2018, 130, '1080p', 1, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Filme Novo da Atriz Y', 2020, 140, '1080p', 1, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Visão Quádrupla', 2020, 100, '4K', 3, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('O Olho do Japão', 2021, 110, '4K', 4, 2, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Mente Criativa', 2022, 120, '4K', 1, 3, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Épico do A', 2008, 185, 'SD', 1, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Jornada de B', 2009, 190, 'SD', 1, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('A Verdade de X', 2007, 181, 'SD', 1, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('O Legado', 2024, 115, '1080p', 1, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Caminhos Cruzados', 2023, 130, '4K', 1, 1, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('O Enigma Antigo', 2023, 105, '1080p', 4, 2, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Sombra da Montanha', 2024, 125, '4K', 4, 2, 4, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('A Travessia Noturna', 2021, 100, '1080p', 4, 8, 3, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Cidade Sitiada', 2022, 115, '4K', 3, 8, 4, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Risadas Eternas', 2022, 90, '1080p', 2, 1, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Palhaçada Global', 2023, 95, '4K', 2, 3, 2, 'S'); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Comédia Inesperada', 2024, 85, '1080p', 2, 4, 2, 'S'); 

-- Inserções para a tabela SERIE
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('O Tempo Perdido', 2020, 1, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('O Último Samurai', 2018, 3, 2, 3, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Mundo Digital', 2022, 4, 3, 4, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Família Feliz', 2015, 2, 4, 1, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('O Mistério de Paris', 2019, 4, 5, 3, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('A Vila Escondida', 2021, 1, 9, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Lendas Alemãs', 2018, 1, 6, 3, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Crimes de Madrid', 2017, 4, 7, 3, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Mistérios de Roma', 2016, 4, 8, 4, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Vozes do Passado', 2019, 1, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Caminhos do Bushido', 2020, 3, 2, 3, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Floresta Sombria', 2021, 4, 3, 4, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Contos Infantis', 2005, 2, 1, 1, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Mundo da Imaginação', 2006, 2, 2, 1, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Aventuras no Espaço', 2007, 5, 3, 1, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Série Premiada Ator', 2015, 1, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Série B Premiada', 2016, 1, 1, 2, 'S');
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Série C Premiada', 2017, 1, 2, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Série Antiga do Ator A', 2000, 1, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Série Antiga do Ator B', 2002, 1, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Série Antiga da Atriz Y', 2001, 1, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('A Cidade Secreta', 2022, 4, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Jornadas Misteriosas', 2023, 4, 2, 3, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('O Labirinto Digital', 2024, 4, 3, 4, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Rindo Alto', 2023, 2, 1, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Missão Perigosa', 2024, 3, 1, 3, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Guerra Silenciosa', 2022, 3, 2, 4, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('A Lei da Cidade', 2021, 3, 8, 4, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Humor Sem Limites', 2021, 2, 2, 2, 'S'); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Gags e Risos', 2020, 2, 3, 2, 'S'); 

-- Inserções para a tabela TEMPORADA
INSERT INTO temporada (id_serie, numero_temp) VALUES (1, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (1, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (1, 3); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (2, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (2, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (3, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (4, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (5, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (6, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (7, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (7, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (7, 3); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (7, 4); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (8, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (8, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (8, 3); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (8, 4); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (9, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (9, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (9, 3); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (9, 4); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (10, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (11, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (12, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (13, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (13, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (13, 3); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (13, 4); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (14, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (14, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (14, 3); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (14, 4); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (15, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (15, 2); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (15, 3); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (15, 4); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (16, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (17, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (18, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (19, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (20, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (21, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (22, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (23, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (24, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (25, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (26, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (27, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (28, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (29, 1); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (30, 1); 

-- Inserções para a tabela EPISODIO
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (1, 1, 'Início da Jornada', 45, TO_DATE('2020-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (1, 2, 'O Despertar', 50, TO_DATE('2020-01-08', 'YYYY-MM-DD'));
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (2, 1, 'Novos Horizontes', 48, TO_DATE('2020-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (3, 1, 'O Retorno', 55, TO_DATE('2021-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (4, 1, 'O Caminho do Guerreiro', 60, TO_DATE('2018-03-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (5, 1, 'A Honra Final', 65, TO_DATE('2019-03-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (6, 1, 'O Código Quebrado', 40, TO_DATE('2022-05-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (7, 1, 'O Primeiro Sorriso', 25, TO_DATE('2015-02-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (8, 1, 'A Cidade Luz', 50, TO_DATE('2019-04-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (9, 1, 'Os Guardiões da Vila', 45, TO_DATE('2021-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (10, 1, 'A Ascensão dos Reis', 50, TO_DATE('2018-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (11, 1, 'O Coração do Império', 52, TO_DATE('2018-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (12, 1, 'O Legado Antigo', 51, TO_DATE('2019-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (13, 1, 'A Coroa Perdida', 53, TO_DATE('2019-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (14, 1, 'O Despertar da Justiçia', 55, TO_DATE('2017-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (15, 1, 'Sombras de um Segredo', 54, TO_DATE('2017-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (16, 1, 'A Conspiração', 56, TO_DATE('2018-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (17, 1, 'A Verdade Revelada', 57, TO_DATE('2018-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (18, 1, 'Mistério no Coliseu', 50, TO_DATE('2016-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (19, 1, 'O Segredo da Catacumba', 52, TO_DATE('2016-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (20, 1, 'O Último Imperador', 51, TO_DATE('2017-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (21, 1, 'A Vingança dos Deuses', 53, TO_DATE('2017-06-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (22, 1, 'Primeira Voz', 50, TO_DATE('2019-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (23, 1, 'O Código', 48, TO_DATE('2020-03-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (24, 1, 'O Desaparecimento', 55, TO_DATE('2021-05-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (25, 1, 'O Reino Encantado', 30, TO_DATE('2005-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (26, 1, 'A Fada Escondida', 30, TO_DATE('2005-02-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (27, 1, 'O Dragão Amigo', 30, TO_DATE('2005-03-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (28, 1, 'A Princesa e o Sapo', 30, TO_DATE('2005-04-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (29, 1, 'A Floresta Mágica', 35, TO_DATE('2006-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (30, 1, 'O Castelo Flutuante', 35, TO_DATE('2006-02-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (31, 1, 'A Ponte Dourada', 35, TO_DATE('2006-03-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (32, 1, 'O Tesouro Escondido', 35, TO_DATE('2006-04-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (33, 1, 'A Missão Secreta', 40, TO_DATE('2007-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (34, 1, 'Encontro Estelar', 40, TO_DATE('2007-02-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (35, 1, 'A Nova Galáxia', 40, TO_DATE('2007-03-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (36, 1, 'O Planeta Desconhecido', 40, TO_DATE('2007-04-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (37, 1, 'Episodio Premiado', 50, TO_DATE('2015-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (38, 1, 'Episodio B', 50, TO_DATE('2016-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (39, 1, 'Episodio C', 50, TO_DATE('2017-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (40, 1, 'Primeiro Episódio A', 40, TO_DATE('2000-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (41, 1, 'Primeiro Episódio B', 40, TO_DATE('2002-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (42, 1, 'Primeiro Episódio Y', 40, TO_DATE('2001-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (43, 1, 'O Início do Segredo', 48, TO_DATE('2022-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (43, 2, 'Os Murmúrios', 49, TO_DATE('2022-01-08', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (43, 3, 'A Busca Continua', 47, TO_DATE('2022-01-15', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (43, 4, 'Revelações Sombrias', 50, TO_DATE('2022-01-22', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (44, 1, 'O Enigma da Floresta', 46, TO_DATE('2023-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (44, 2, 'O Mapa Oculto', 47, TO_DATE('2023-01-08', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (44, 3, 'As Pistas Antigas', 48, TO_DATE('2023-01-15', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (44, 4, 'A Solução Final', 49, TO_DATE('2023-01-22', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (45, 1, 'O Ponto de Partida', 45, TO_DATE('2024-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (45, 2, 'A Teia Virtual', 46, TO_DATE('2024-01-08', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (45, 3, 'Conflitos de Código', 47, TO_DATE('2024-01-15', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (45, 4, 'A Saída Encontrada', 48, TO_DATE('2024-01-22', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (46, 1, 'Piada Inicial', 46, TO_DATE('2023-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (46, 2, 'Situação Engraçada', 48, TO_DATE('2023-01-08', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (46, 3, 'Gargalhadas Finais', 49, TO_DATE('2023-01-15', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (47, 1, 'Início da Explosão', 47, TO_DATE('2024-01-01', 'YYYY-MM-DD'));
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (47, 2, 'Perseguição Insana', 49, TO_DATE('2024-01-08', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (47, 3, 'Confronto Final', 50, TO_DATE('2024-01-15', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (48, 1, 'Infiltração Noturna', 45, TO_DATE('2022-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (48, 2, 'Contra-Ataque', 46, TO_DATE('2022-01-08', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (48, 3, 'Decisão Final', 47, TO_DATE('2022-01-15', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (49, 1, 'Início da Ordem', 50, TO_DATE('2021-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (50, 1, 'Primeiro Ato Cômico', 40, TO_DATE('2021-01-01', 'YYYY-MM-DD')); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (51, 1, 'O Início da Diversão', 35, TO_DATE('2020-01-01', 'YYYY-MM-DD')); 

-- Inserções para a tabela PREMIACAO
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_filme) VALUES ('Melhor Filme de Drama', 2021, 'Filme', 1); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_serie) VALUES ('Melhor Série de Suspense', 2023, 'Série', 3); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_filme) VALUES ('Melhor Ator Coadjuvante', 2022, 'Atuação', 5, 2); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_diretor, id_serie) VALUES ('Melhor Diretor de Série', 2021, 'Direção', 1, 1); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_temporada) VALUES ('Melhor Temporada', 2019, 'Série', 4); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_serie, id_temporada) VALUES ('Melhor Ator Coadjuvante', 2019, 'Atuação', 8, 7, 10); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_serie, id_temporada) VALUES ('Ator Revelação', 2021, 'Atuação', 8, 7, 12); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_serie, id_temporada) VALUES ('Melhor Elenco', 2018, 'Atuação', 9, 8, 14); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_serie, id_temporada) VALUES ('Destaque Dramático', 2020, 'Atuação', 9, 8, 16); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_serie, id_temporada) VALUES ('Melhor Ator Principal', 2017, 'Atuação', 10, 9, 18);
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_serie, id_temporada) VALUES ('Grande Performance', 2019, 'Atuação', 10, 9, 20); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_filme) VALUES ('Melhor Ator Principal', 2024, 'Atuação', 5, 4); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_diretor, id_filme) VALUES ('Melhor Direção', 2024, 'Direção', 1, 4); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_filme) VALUES ('Melhor Atriz Coadjuvante', 2023, 'Atuação', 3, 5); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_diretor, id_filme) VALUES ('Direção de Arte', 2023, 'Direção', 3, 5); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_filme) VALUES ('Melhor Ator', 2022, 'Atuação', 16, 6); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_diretor, id_filme) VALUES ('Melhor Diretor', 2022, 'Direção', 4, 6); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_filme) VALUES ('Prêmio de Aventura', 2001, 'Geral', 7);
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_filme) VALUES ('Exploração do Ano', 2003, 'Aventura', 8);
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_filme) VALUES ('Melhor Enredo de Aventura', 2002, 'Geral', 9);
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_serie, id_ator) VALUES ('Atuação em Série', 2016, 'Ator', 16, 1); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_serie) VALUES ('Série do Ano', 2016, 'Melhor Série', 16);
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_serie, id_ator) VALUES ('Atuação Incrível', 2017, 'Ator', 17, 2); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_serie, id_ator) VALUES ('Melhor Performance', 2018, 'Ator', 18, 3); 
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_filme) VALUES ('Filme Clássico', 2009, 'Geral', 22);
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_ator, id_filme) VALUES ('Melhor Ator Veterano', 2010, 'Atuação', 18, 23);
INSERT INTO premiacao (titulo_premio, ano_premio, categoria, id_filme) VALUES ('Documentário Revelação', 2008, 'Documentário', 24);

-- Inserções para a tabela ATOR_FILME
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (1, 1, 1); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (5, 2, 2); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (7, 3, 3); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (17, 10, 1);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (18, 11, 2);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (19, 12, 3);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (1, 13, 1); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (2, 14, 2); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (3, 15, 4); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (17, 16, 1);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (18, 17, 2);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (20, 18, 3);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (1, 19, 1); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (3, 20, 4); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (4, 21, 1); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (17, 22, 8);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (18, 23, 9);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (5, 24, 10);


-- Inserções para a tabela ATOR_EPISODIO
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 1, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (2, 2, 2); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (3, 3, 4); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (4, 4, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 5, 2); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 6, 3); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (7, 7, 4); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (12, 8, 5); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (11, 9, 6); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (16, 10, 7);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 23, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (2, 23, 2); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 23, 3); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (13, 24, 4);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (14, 24, 5);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 24, 7); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (4, 25, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (15, 25, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (16, 25, 3);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 38, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (2, 39, 2); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (3, 40, 4); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (17, 41, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (18, 42, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (20, 43, 3);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 44, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (2, 44, 2); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 45, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (2, 45, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 46, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (2, 46, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 47, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (2, 47, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (3, 48, 4); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 48, 7); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (3, 49, 4);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 49, 7);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (3, 50, 4);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 50, 7);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (3, 51, 4);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 51, 7);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (4, 52, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (16, 52, 7); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (4, 53, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (16, 53, 7);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (4, 54, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (16, 54, 7);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (4, 55, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (16, 55, 7);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 56, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 56, 2); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 57, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 57, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (1, 58, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 58, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 59, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 59, 2); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 60, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 60, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (5, 61, 1);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 61, 2);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (13, 62, 4); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (14, 62, 5); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (13, 63, 4);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (14, 63, 5);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (13, 64, 4);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (14, 64, 5);
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (3, 66, 4); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (6, 66, 7); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (17, 67, 1); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (18, 67, 2); 

-- Inserções para a tabela DIRETOR_FILME
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (1, 1); 
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (3, 2); 
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (4, 3); 
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (1, 4); 
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (3, 5); 
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (4, 6); 
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (1, 19);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (3, 20);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (4, 21);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (1, 25);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (1, 26);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (3, 27);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (3, 28);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (5, 29);
INSERT INTO diretor_filme (id_diretor, id_filme) VALUES (5, 30);

-- Inserções para a tabela DIRETOR_EPISODIO
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 1); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 1); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (3, 3); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (4, 3); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (6, 5); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (7, 6); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (8, 7); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (9, 7); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 23); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 23); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (8, 24); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (9, 24); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 25); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (4, 25); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (10, 26);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (10, 27);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (10, 28);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (11, 30);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (11, 31);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (11, 32);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (10, 34);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (11, 35);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (10, 36);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 56); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 56); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 57);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 57);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 58);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 58);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 59);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 59);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 60);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 60);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (1, 61);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (2, 61);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (8, 62); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (9, 62); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (8, 63);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (9, 63);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (8, 64);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (9, 64);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (5, 65);

-- Inserções para a tabela AVALIACAO
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (1, 8.5, 'Filme excelente!');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (2, 7.0, 'Bom filme, mas o final é previsível.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (3, 9.0, 'Muita ação!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (1, 7.8, 'Começo promissor.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (2, 8.2, 'Desenvolvimento interessante.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (3, 7.5, 'Novos ares na série.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (4, 8.0, 'Reviravolta surpreendente.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (5, 9.2, 'Melhor episódio da temporada!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (56, 8.0, 'Muito bom!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (56, 9.0, 'Hilário!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (57, 7.0, 'Engraçado.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (57, 8.5, 'Adorei!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (58, 9.5, 'Melhor episódio!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (58, 8.0, 'Excelente comédia.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (59, 8.0, 'Muita ação!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (59, 9.0, 'Adrenalina pura!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (60, 7.5, 'Cenas incríveis.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (60, 8.5, 'Prendeu minha atenção.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (61, 9.0, 'Final épico!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (61, 8.0, 'Fantástico.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (62, 8.0, 'Ótima estratégia!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (62, 8.5, 'Cenas de ação realistas.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (63, 7.8, 'Gostei muito.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (63, 8.2, 'Intenso.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (64, 9.0, 'Uau, que final!');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (64, 8.8, 'Recomendado.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (4, 8.0, 'Excelente direção!'); 
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (4, 9.0, 'Genial!');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (25, 7.5, 'Direção sólida.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (25, 8.5, 'Bom enredo.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (26, 8.0, 'Impactante.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (26, 7.0, 'História complexa.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (5, 7.0, 'Direção interessante.'); 
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (5, 7.5, 'Trama envolvente.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (27, 8.0, 'Mistério bem construído.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (27, 8.5, 'Suspense de tirar o fôlego.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (28, 9.0, 'Visuais deslumbrantes.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (28, 8.5, 'Ritmo perfeito.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (1, 8.5, 'Direção forte.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (1, 9.0, 'Um mestre!');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (29, 7.8, 'Boa produção.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (29, 8.2, 'Intrigante.');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (30, 8.5, 'Ação de primeira!');
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (30, 9.0, 'Um clássico instantâneo.');
INSERT INTO avaliacao (id_episodio, nota, comentario) VALUES (65, 8.0, 'Bem dirigida.');
INSERT INTO avaliacao (id_filme, nota, comentario, id_ator) VALUES (31, 9.0, 'Hilário, ator A gostou!', 1);
INSERT INTO avaliacao (id_filme, nota, comentario, id_ator) VALUES (31, 8.8, 'Simplesmente perfeito, ator B gostou!', 2);
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (31, 7.0, 'Legal.', NULL);
INSERT INTO avaliacao (id_filme, nota, comentario, id_ator) VALUES (32, 9.2, 'Morri de rir, ator D avaliou!', 4);
INSERT INTO avaliacao (id_filme, nota, comentario, id_ator) VALUES (32, 8.9, 'Excelente! Ator X concordou!', 5);
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (32, 6.5, 'Esperava mais.', NULL);
INSERT INTO avaliacao (id_filme, nota, comentario, id_ator) VALUES (33, 8.6, 'Muito engraçado, ator Velho A disse!', 17);
INSERT INTO avaliacao (id_filme, nota, comentario, id_ator) VALUES (33, 9.1, 'Sensacional, ator Velho B concordou!', 18);
INSERT INTO avaliacao (id_filme, nota, comentario) VALUES (33, 7.2, 'Razoável.', NULL);
INSERT INTO avaliacao (id_episodio, nota, comentario, id_ator) VALUES (56, 9.0, 'Mais risadas do Ator X', 5); 
INSERT INTO avaliacao (id_episodio, nota, comentario, id_ator) VALUES (57, 8.7, 'Atriz A curtiu!', 1);  
INSERT INTO avaliacao (id_episodio, nota, comentario, id_ator) VALUES (66, 9.5, 'Atriz C avaliou!', 3);
INSERT INTO avaliacao (id_episodio, nota, comentario, id_ator) VALUES (66, 8.8, 'Ator Y adorou!', 6);
INSERT INTO avaliacao (id_episodio, nota, comentario, id_ator) VALUES (67, 9.1, 'Ator Velho A aprovou!', 17);
INSERT INTO avaliacao (id_episodio, nota, comentario, id_ator) VALUES (67, 8.9, 'Ator Velho B achou top!', 18);

INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Sem Premio', 'M', TO_DATE('1990-05-20', 'YYYY-MM-DD'), 1); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Um Novo Amor', 2015, 105, '1080p', 6, 1, 2, 'S');
INSERT INTO personagem (nome_personagem) VALUES ('Ator Sem Premio'); 
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (
    (SELECT id_ator FROM ator WHERE nome = 'Ator Sem Premio'),
    (SELECT id_filme FROM filme WHERE titulo = 'Um Novo Amor'),
    (SELECT id_personagem FROM personagem WHERE nome_personagem = 'Ator Sem Premio')
);

INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Antigo e Novo', 'M', TO_DATE('1965-07-10', 'YYYY-MM-DD'), 1); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Cronicas do Passado', 1999, 1, 1, 2, 'S'); 
INSERT INTO temporada (id_serie, numero_temp) VALUES ((SELECT id_serie FROM serie WHERE titulo = 'Cronicas do Passado'), 1); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES ((SELECT id_temporada FROM temporada WHERE id_serie = (SELECT id_serie FROM serie WHERE titulo = 'Cronicas do Passado')), 1, 'Primeiro Capitulo', 45, TO_DATE('1999-01-15', 'YYYY-MM-DD')); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('Futuro Brilhante', 2022, 115, '1080p', 1, 1, 2, 'S');
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Antigo e Novo'); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (
    (SELECT id_ator FROM ator WHERE nome = 'Ator Antigo e Novo'),
    (SELECT id_episodio FROM episodio WHERE titulo = 'Primeiro Capitulo'),
    (SELECT id_personagem FROM personagem WHERE nome_personagem = 'Personagem Antigo e Novo')
);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (
    (SELECT id_ator FROM ator WHERE nome = 'Ator Antigo e Novo'),
    (SELECT id_filme FROM filme WHERE titulo = 'Futuro Brilhante'),
    (SELECT id_personagem FROM personagem WHERE nome_personagem = 'Personagem Antigo e Novo')
);

INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Histórico Moderno', 'M', TO_DATE('1970-03-01', 'YYYY-MM-DD'), 1); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Memorias Antigas', 2001, 1, 1, 2, 'S'); 
INSERT INTO temporada (id_serie, numero_temp) VALUES (
    (SELECT id_serie FROM serie WHERE titulo = 'Memorias Antigas'), 1
); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (
    (SELECT id_temporada FROM temporada WHERE id_serie = (SELECT id_serie FROM serie WHERE titulo = 'Memorias Antigas')),
    1, 'O Legado Esquecido', 48, TO_DATE('2001-05-10', 'YYYY-MM-DD')
); 
INSERT INTO filme (titulo, ano_lanc, duracao_min, resolucao, id_genero, id_pais, id_classificacao, ativo) VALUES ('A Reconexao', 2017, 125, '1080p', 4, 1, 3, 'S'); 
INSERT INTO personagem (nome_personagem) VALUES ('Personagem Novo e Velho'); 
INSERT INTO ator_episodio (id_ator, id_episodio, id_personagem) VALUES (
    (SELECT id_ator FROM ator WHERE nome = 'Ator Histórico Moderno'),
    (SELECT id_episodio FROM episodio WHERE titulo = 'O Legado Esquecido'),
    (SELECT id_personagem FROM personagem WHERE nome_personagem = 'Personagem Novo e Velho')
);
INSERT INTO ator_filme (id_ator, id_filme, id_personagem) VALUES (
    (SELECT id_ator FROM ator WHERE nome = 'Ator Histórico Moderno'),
    (SELECT id_filme FROM filme WHERE titulo = 'A Reconexao'),
    (SELECT id_personagem FROM personagem WHERE nome_personagem = 'Personagem Novo e Velho')
);
INSERT INTO diretor (nome, data_nasc, id_pais) VALUES ('Diretor da Acao', TO_DATE('1975-01-01', 'YYYY-MM-DD'), 1); 
INSERT INTO diretor (nome, data_nasc, id_pais) VALUES ('Diretora Ajudante', TO_DATE('1980-02-02', 'YYYY-MM-DD'), 1); 
INSERT INTO serie (titulo, ano_estreia, id_genero, id_pais, id_classificacao, ativa) VALUES ('Missao Impossivel X', 2023, (SELECT id_genero FROM genero WHERE descricao = 'Ação'), 1, 3, 'S');
INSERT INTO temporada (id_serie, numero_temp) VALUES ((SELECT id_serie FROM serie WHERE titulo = 'Missao Impossivel X'), 1); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (
    (SELECT id_temporada FROM temporada WHERE id_serie = (SELECT id_serie FROM serie WHERE titulo = 'Missao Impossivel X')),
    1, 'A Invasao Noturna', 46, TO_DATE('2023-01-10', 'YYYY-MM-DD')
); 
INSERT INTO episodio (id_temporada, numero_ep, titulo, duracao_min, data_exibicao) VALUES (
    (SELECT id_temporada FROM temporada WHERE id_serie = (SELECT id_serie FROM serie WHERE titulo = 'Missao Impossivel X')),
    2, 'O Resgate Final', 48, TO_DATE('2023-01-17', 'YYYY-MM-DD')
); 
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (
    (SELECT id_diretor FROM diretor WHERE nome = 'Diretor da Acao'),
    (SELECT id_episodio FROM episodio WHERE titulo = 'A Invasao Noturna')
);
INSERT INTO diretor_episodio (id_diretor, id_episodio) VALUES (
    (SELECT id_diretor FROM diretor WHERE nome = 'Diretora Ajudante'),
    (SELECT id_episodio FROM episodio WHERE titulo = 'O Resgate Final')
);
INSERT INTO ator (nome, sexo, data_nasc, id_pais) VALUES ('Ator Avaliador X', 'M', TO_DATE('1985-06-15', 'YYYY-MM-DD'), 1); 
INSERT INTO avaliacao (id_episodio, id_ator, nota) VALUES (
    (SELECT id_episodio FROM episodio WHERE titulo = 'A Invasao Noturna'),
    (SELECT id_ator FROM ator WHERE nome = 'Ator Avaliador X'),
    9
);
INSERT INTO avaliacao (id_episodio, id_ator, nota) VALUES (
    (SELECT id_episodio FROM episodio WHERE titulo = 'O Resgate Final'),
    (SELECT id_ator FROM ator WHERE nome = 'Ator Avaliador X'),
    8
);